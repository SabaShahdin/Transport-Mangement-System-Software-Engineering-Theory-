document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('signupForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const loader = document.getElementById('loader');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        let isValid = true;
        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        const confirmPassword = confirmPasswordInput.value.trim();

        // Clear previous errors
        usernameError.style.display = 'none';
        passwordError.style.display = 'none';
        confirmPasswordError.style.display = 'none';

        // Validation
        if (username === '') {
            usernameError.style.display = 'block';
            isValid = false;
        }
        if (password.length < 6) {
            passwordError.style.display = 'block';
            isValid = false;
        }
        if (password !== confirmPassword) {
            confirmPasswordError.style.display = 'block';
            isValid = false;
        }

        if (isValid) {
            loader.style.display = 'block'; // Show loader

            // Simulate a delay (e.g., for server request)
            setTimeout(function() {
                loader.style.display = 'none'; // Hide loader
                alert('Signup successful!');

                // Create a Blob to store the signup data
                const signupData = `Username: ${username}\nPassword: ${password}`;
                const blob = new Blob([signupData], { type: 'text/plain' });

                // Create a link element for downloading the file
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = 'signup_data.txt'; // Set the file name

                // Programmatically trigger the download
                downloadLink.click();

                // Clear the form fields (optional)
                form.reset();

                // Redirect to dashboard (in a real system, you'd send the form data to the server)
                window.location.href = '/dashboard';
            }, 2000);
        }
    });
});
